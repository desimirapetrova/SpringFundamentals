package softuni.exam24;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Exam24ApplicationTests {

    @Test
    void contextLoads() {
    }

}
