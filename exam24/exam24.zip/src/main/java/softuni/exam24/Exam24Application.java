package softuni.exam24;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exam24Application {

    public static void main(String[] args) {
        SpringApplication.run(Exam24Application.class, args);
    }

}
