package softuni.exam24.model.binding;

public class SelectedMyShip {
   private String name;
   private Long power;
   private Long health;
}
