package softuni.exam24.model.entity.enums;

public enum CategoryEnum {
    BATTLE,
    CARGO,
    PATROL;
}
